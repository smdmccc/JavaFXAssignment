package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class NameFormatter extends Application {
	
	private TextField titleField;
	private TextField firstField;
	private TextField middleField;
	private TextField lastField;

	public static void main(String[] args) {
		//* Launch the application
		launch(args); 
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		
		// Here I am asking user for an input as a textfield and converting it to a string to be used later
		
		// Label asks for user input
		Label titleLabel = new Label (" Enter your title: ");
		
		// TextFields record user input
		titleField = new TextField();
		String title = titleField.getText();
		
		// Label asks for user input
		Label firstLabel = new Label (" Enter your First Name: ");
		// TextFields record user input
		firstField = new TextField();
		String first = firstField.getText();

		// Label asks for user input
		Label middleLabel = new Label (" Enter your title: ");
		// TextFields record user input
		middleField = new TextField();
		String middle = middleField.getText();


		// Label asks for user input
		Label lastLabel = new Label (" Enter your title: ");
		// TextFields record user input
		lastField = new TextField();
		String last = lastField.getText();

		// Here I create buttons that are labeled based on what their output will be
						
		// Create the buttons for each required output
		Button b1 = new Button("Title First Middle Last ");
		Button b2 = new Button("First Middle Last ");
		Button b3 = new Button("First Last");
		Button b4 = new Button("Last, First, Middle, Title");
		Button b5 = new Button("Last, First, Middle");
		Button b6 = new Button("Last, First");
		
		
		// Create the output Label
		Label outputLabel = new Label();
		
		// Here I give the buttons function, mainly to call the string values created earlier and display them in the proper format
		
		b1.setOnAction(e -> {
			String output = new String(title + " " + first + " " + middle + " " + last);
			
			outputLabel.setText(output);
			
		});
		
		b2.setOnAction(e -> {
			outputLabel.setText(firstField.getText());
		});
		
		b3.setOnAction(e -> {
			outputLabel.setText(middleField.getText());
		});
		
		b4.setOnAction(e -> {
			outputLabel.setText(lastField.getText());
		});
		
		b5.setOnAction(e -> {
			outputLabel.setText(titleField.getText());
		});
		
		b6.setOnAction(e -> {
			outputLabel.setText(titleField.getText());
		});
					
		// Create initial HBox
		HBox hbox = new HBox(10, titleLabel, titleField, firstLabel, firstField,
				middleLabel, middleField, lastLabel, lastField );
		
		// Put controls in a VBox
		VBox vbox = new VBox(10, hbox, b1, b2, b3, b4, b5, b6, outputLabel);
		
		// Set the alignment
		vbox.setAlignment(Pos.CENTER);
		
		// Set the padding to 10 pixels
		vbox.setPadding(new Insets(10));
		
		// Add the VBox to a scene
		Scene scene = new Scene(vbox);
		
		// Set the Stage Title
		primaryStage.setTitle("Name Formatter");
				
		// Set the scene to the stage and display it
		primaryStage.setScene(scene);
		primaryStage.show();		
		
	}
	
}
