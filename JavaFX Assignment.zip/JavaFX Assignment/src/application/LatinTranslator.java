package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LatinTranslator extends Application {
	
	public static void main(String[] args) {
		//* Launch the application
		launch(args); 
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// Create the buttons
		
		Button sinisterButton = new Button("Sinister");
		Button dexterButton = new Button("Dexter");
		Button mediumButton = new Button("Medium");
		
		// Create the output Label
		Label outputLabel = new Label();
		
		// Register event handlers for the buttons
		sinisterButton.setOnAction(e -> {
			outputLabel.setText("Left");
		});
		
		dexterButton.setOnAction(e -> {
			outputLabel.setText("Right");
		});
		
		mediumButton.setOnAction(e -> {
			outputLabel.setText("Center");
		});
		
		// Put controls in a VBox
		VBox vbox = new VBox(10, sinisterButton, dexterButton, mediumButton, outputLabel);
		
		// Set the alignment
		vbox.setAlignment(Pos.CENTER);
		
		// Set the padding to 10 pixels
		vbox.setPadding(new Insets(10));
		
		// Add the VBox to a scene
		Scene scene = new Scene(vbox);
				
		// Set the scene to the stage and display it
		primaryStage.setScene(scene);
		primaryStage.show();		
		
	}

}
